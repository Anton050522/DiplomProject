﻿using ClosedXML.Excel;
using CommonClasses.PaginationAndSort.Filters;
using CommonClasses.PaginationAndSort.IndexViewModelClasses;
using CommonClasses.PaginationAndSort.PageViewClass;
using CommonClasses.PaginationAndSort.SortingClasses;
using EnumExt;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Project.BLL.Services.IServiceIntefaces;
using RailDBProject.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebTestOfVMC.Models;

namespace WebApplication.Controllers
{
    public class DefectController : Controller
    {
        private readonly IDefectServices _defectService;
        private readonly ILocalSectionServices _localSectionServices;

        public DefectController(IDefectServices _defectService, ILocalSectionServices _localSectionServices)
        {
            this._defectService = _defectService;
            this._localSectionServices = _localSectionServices;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var defects = _defectService.GetAll();

            var model = new List<DefectInfo>();

            model = defects.Select(o => new DefectInfo
            {
                DefectCode = o.DefectCode,
                DefectLenght = o.DefectLenght,
                DefectDepth = o.DefectDepth,
                DateOfDetection = o.DateOfDetection,
                Path = o.Path,
                ManufactureYear = o.ManufactureYear,
                DefectId = o.DefectId,
                WaySide = o.WaySide
            }).ToList();

            return View(model);
        }

        public async Task<IActionResult> Index(int? defect, string name, int page = 1, DefectSortState sortOrder = DefectSortState.DateOfDetectionAsc)
        {
            int pageSize = 10;

            IQueryable<Defect> defects = _defectService.GetQuarable();


            if (defect != null && defect != 0)
            {
                defects = defects.Where(d => d.DefectId == defect);
            }

            switch (sortOrder)
            {
                case DefectSortState.DateOfDetectionDesc:
                    defects = defects.OrderByDescending(s => s.DateOfDetection);
                    break;
                case DefectSortState.DateOfDetectionAsc:
                    defects = defects.OrderBy(s => s.DateOfDetection);
                    break;
                case DefectSortState.DefectCodeDesc:
                    defects = defects.OrderByDescending(s => s.DefectCode);
                    break;
                case DefectSortState.DefectCodeAsc:
                    defects = defects.OrderBy(s => s.DefectCode);
                    break;
                case DefectSortState.DefectDepthDesc:
                    defects = defects.OrderByDescending(s => s.DefectDepth);
                    break;
                case DefectSortState.DefectDepthAsc:
                    defects = defects.OrderBy(s => s.DefectDepth);
                    break;
                case DefectSortState.DefectLenghtDesc:
                    defects = defects.OrderByDescending(s => s.DefectLenght);
                    break;
                case DefectSortState.DefectLenghtAsc:
                    defects = defects.OrderBy(s => s.DefectLenght);
                    break;
                case DefectSortState.KilometerDesc:
                    defects = defects.OrderByDescending(s => s.Kilometer);
                    break;
                case DefectSortState.KilometerAsc:
                    defects = defects.OrderBy(s => s.Kilometer);
                    break;
                case DefectSortState.PktDesc:
                    defects = defects.OrderByDescending(s => s.Pkt);
                    break;
                case DefectSortState.PktAsc:
                    defects = defects.OrderBy(s => s.Pkt);
                    break;
                case DefectSortState.WaySideDesc:
                    defects = defects.OrderByDescending(s => s.WaySide);
                    break;
                case DefectSortState.WaySideAsc:
                    defects = defects.OrderBy(s => s.WaySide);
                    break;
                case DefectSortState.PathDesc:
                    defects = defects.OrderByDescending(s => s.Path);
                    break;
                case DefectSortState.PathAsc:
                    defects = defects.OrderBy(s => s.Path);
                    break;
            }

            var count = await defects.CountAsync();
            var items = await defects.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();

            DefectIndexViewModel viewModel = new DefectIndexViewModel
            {
                PageView = new PageView(count, page, pageSize),
                DefectSortViewModel = new DefectSortViewModel(sortOrder),
                DefectFilter = new DefectFilter(_defectService.GetDefectList(), defect, name),
                Defects = items
            };
            return View(viewModel);
        }
        public ActionResult Export()
        {
            
                List<Defect> _defect = _defectService.GetAll();
                
                using (IXLWorkbook workbook = new XLWorkbook())
                {
                    var worksheet = workbook.Worksheets.Add("Defect");


                    //worksheet.FirstCell().InsertTable(dt);


                worksheet.Cell(1, 1).Value = "Дата обнражуения дефекта";
                worksheet.Cell(1, 2).Value = "Наименование кода дефекта";
                worksheet.Cell(1, 3).Value = "Код дефекта";
                worksheet.Cell(1, 4).Value = "Глубина дефекта";
                worksheet.Cell(1, 5).Value = "Длина дефекта";
                worksheet.Cell(1, 6).Value = "Киллометр";
                worksheet.Cell(1, 7).Value = "Местонахождение";
                worksheet.Cell(1, 8).Value = "Завод изготовитель";
                worksheet.Cell(1, 9).Value = "Год выпуска";
                worksheet.Cell(1, 10).Value = "Путь";
                worksheet.Cell(1, 11).Value = "Пикет";
                worksheet.Cell(1, 12).Value = "Рельса";

                worksheet.Row(1).Style.Font.Bold = true;

                    for (int i = 0; i < _defect.Count; i++)
                    {
                        worksheet.Cell(i + 2, 1).Value = _defect[i].DateOfDetection;
                        worksheet.Cell(i + 2, 2).Value = _defect[i].DefectCodeName;
                        worksheet.Cell(i + 2, 3).Value = _defect[i].DefectCode.GetEnumDescription();
                        worksheet.Cell(i + 2, 4).Value = _defect[i].DefectDepth;
                        worksheet.Cell(i + 2, 5).Value = _defect[i].DefectLenght;
                        worksheet.Cell(i + 2, 6).Value = _defect[i].Kilometer;
                        worksheet.Cell(i + 2, 7).Value = _defect[i].LocalSection.LocalSectionName;
                        worksheet.Cell(i + 2, 8).Value = _defect[i].Manufacture.GetEnumDescription();
                        worksheet.Cell(i + 2, 9).Value = _defect[i].ManufactureYear;
                        worksheet.Cell(i + 2, 10).Value = _defect[i].Path;
                        worksheet.Cell(i + 2, 11).Value = _defect[i].Pkt;
                        worksheet.Cell(i + 2, 12).Value = _defect[i].WaySide.GetEnumDescription();
                    }

                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        stream.Flush();

                        return new FileContentResult(stream.ToArray(),
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                        {
                            FileDownloadName = $"Все дефекты по состоянию на {DateTime.UtcNow.ToShortDateString()}.xlsx"
                        };
                    }
                }
            }
            
         
    }
}
