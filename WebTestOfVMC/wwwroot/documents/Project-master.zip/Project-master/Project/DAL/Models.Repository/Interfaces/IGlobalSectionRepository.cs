﻿using Project.RepositoryPattern;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Linq.Expressions;
using System.Collections;

namespace Project.Models.Repository.Interfaces
{
    public interface IGlobalSectionRepository : IRepository<GlobalSection>
    {
        
    }
}
