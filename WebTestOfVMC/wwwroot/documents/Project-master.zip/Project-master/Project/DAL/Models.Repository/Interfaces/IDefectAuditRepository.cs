﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project.DAL.Models.Repository.Interfaces
{
    public interface IDefectAuditRepository
    {
        //Архи закинуть сюда
    }
}
