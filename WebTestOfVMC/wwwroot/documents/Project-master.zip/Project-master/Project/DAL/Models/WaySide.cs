﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project.DAL.Models
{
    public enum WaySide
    {
        Left = 0,
        Right = 1
    }
}
