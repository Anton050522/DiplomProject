﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonClasses.PaginationAndSort.SortingClasses
{
    public enum LocalSectionSortState
    {
        LocalSectionNameAsc,
        LocalSectionNameDesc,

        LocalWayAsc,
        LocalWayDesc
    }
}
