﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonClasses.PaginationAndSort.SortingClasses
{
    public enum GlobalSectionSortState
    {
        GlobalSectionNameAsc,
        GlobalSectionNameDesc,

        GlobalWayAsc,
        GlobalWayDesc
    }
}
