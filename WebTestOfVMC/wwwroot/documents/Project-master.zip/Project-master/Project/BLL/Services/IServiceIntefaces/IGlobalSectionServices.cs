﻿using Project.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Project.BLL.Services.IServiceIntefaces
{
    public interface IGlobalSectionServices
    {
    }
}
