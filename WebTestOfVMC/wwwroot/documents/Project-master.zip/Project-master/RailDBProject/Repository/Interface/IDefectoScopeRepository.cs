﻿using RailDBProject.Model;

namespace RailDBProject.Repository.Interface
{
    public interface IDefectoScopeRepository : IRepository<Defectoscope>
    {
    }
}
