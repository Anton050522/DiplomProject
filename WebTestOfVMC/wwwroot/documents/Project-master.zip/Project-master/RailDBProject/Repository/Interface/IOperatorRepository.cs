﻿using RailDBProject.Model;

namespace RailDBProject.Repository.Interface
{
    public interface IOperatorRepository : IRepository<Operator>
    {
    }
}
