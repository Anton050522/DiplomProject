﻿using RailDBProject.Model;

namespace RailDBProject.Repository.Interface
{
    public interface IUserRepository : IRepository<User>
    {
    }
}
