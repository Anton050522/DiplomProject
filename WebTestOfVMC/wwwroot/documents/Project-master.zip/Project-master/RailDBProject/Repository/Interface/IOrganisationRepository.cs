﻿using RailDBProject.Model;

namespace RailDBProject.Repository.Interface
{
    public interface IOrganisationRepository : IRepository<Organisation>
    {
    }
}
