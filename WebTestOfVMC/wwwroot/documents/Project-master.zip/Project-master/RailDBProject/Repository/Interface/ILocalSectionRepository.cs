﻿using RailDBProject.Model;

namespace RailDBProject.Repository.Interface
{
    public interface ILocalSectionRepository : IRepository<LocalSection>
    {
    }
}
