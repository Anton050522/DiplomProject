﻿using System.ComponentModel;

namespace RailDBProject.Model
{
    public enum WaySide
    {
        [Description("Левая")]
        Left,
        [Description("Правая")]
        Right
    }
}
